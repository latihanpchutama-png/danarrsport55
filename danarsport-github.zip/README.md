# DANARSPORT — Luxury Supercar Showroom

Website showroom mobil sport mewah **DANARSPORT** (Kontak/WhatsApp: **085167029747**).

## Struktur File
- `index.html` — Struktur halaman utama
- `style.css` — Animasi & styling kustom
- `script.js` — Data unit, filter, carousel, simulator kredit, wishlist, perbandingan, & booking test drive
- `images/` — Koleksi foto unit mobil sport mewah

## Cara Deploy ke GitHub Pages
1. Buat repository baru di GitHub (misalnya `danarsport-showroom`).
2. Upload seluruh isi folder ini (`index.html`, `style.css`, `script.js`, dan folder `images/`) ke repository tersebut.
3. Buka **Settings** -> **Pages** di repository GitHub Anda.
4. Pada bagian **Branch**, pilih `main` dan folder `/ (root)`, lalu klik **Save**.
5. Tunggu beberapa saat hingga situs Anda aktif di `https://<username>.github.io/danarsport-showroom/`.

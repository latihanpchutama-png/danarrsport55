const CARS = [
      {
        id: 'huracan-tecnica',
        name: 'Lamborghini Huracán Tecnica',
        brand: 'Lamborghini',
        category: 'Supercar',
        year: 2025,
        status: 'Ready Stock',
        price: 8940000000,
        engine: '5.2L V10 Naturally Aspirated',
        powerHp: 631,
        powerLabel: '631 HP',
        torque: '565 Nm',
        accelSec: 3.2,
        accelLabel: '3.2 dtk',
        topSpeed: '325 km/jam',
        transmission: '7-Speed Dual Clutch',
        color: 'Verde Mantis',
        image: 'images/lamborghini-huracan-tecnica.jpg',
        desc: 'Perpaduan sempurna antara DNA balap Super Trofeo dan kenyamanan jalan raya. Mesin V10 naturally aspirated legendaris dengan sistem kemudi roda belakang.'
      },
      {
        id: 'ferrari-296-gtb',
        name: 'Ferrari 296 GTB',
        brand: 'Ferrari',
        category: 'Hybrid Supercar',
        year: 2025,
        status: 'Ready Stock',
        price: 10999000000,
        engine: '3.0L V6 Twin-Turbo Plug-in Hybrid',
        powerHp: 819,
        powerLabel: '819 HP',
        torque: '740 Nm',
        accelSec: 2.9,
        accelLabel: '2.9 dtk',
        topSpeed: '330 km/jam',
        transmission: '8-Speed F1 DCT',
        color: 'Rosso Corsa',
        image: 'images/ferrari-296-gtb.jpg',
        desc: 'Evolusi berlinetta bermesin tengah Ferrari dengan teknologi hybrid 819 HP yang responsif, desain aerodinamis tajam, dan suara mesin V6 yang memukau.'
      },
      {
        id: 'porsche-911-gt3-rs',
        name: 'Porsche 911 GT3 RS',
        brand: 'Porsche',
        category: 'Track-Focused',
        year: 2025,
        status: 'Limited Unit',
        price: 9850000000,
        engine: '4.0L Flat-6 Naturally Aspirated',
        powerHp: 525,
        powerLabel: '525 PS',
        torque: '465 Nm',
        accelSec: 3.2,
        accelLabel: '3.2 dtk',
        topSpeed: '296 km/jam',
        transmission: '7-Speed PDK',
        color: 'Ice Grey Metallic',
        image: 'images/porsche-911-gt3-rs.jpg',
        desc: 'Dirancang khusus untuk presisi sirkuit dengan sistem aerodinamika aktif DRS, sayap belakang serat karbon masif, dan bobot super ringan.'
      },
      {
        id: 'mclaren-750s',
        name: 'McLaren 750S',
        brand: 'McLaren',
        category: 'Supercar',
        year: 2025,
        status: 'Ready Stock',
        price: 12500000000,
        engine: '4.0L V8 Twin-Turbo',
        powerHp: 740,
        powerLabel: '740 HP',
        torque: '800 Nm',
        accelSec: 2.7,
        accelLabel: '2.7 dtk',
        topSpeed: '332 km/jam',
        transmission: '7-Speed SSG',
        color: 'Papaya Spark',
        image: 'images/mclaren-750s.jpg',
        desc: 'Supercar teringan di kelasnya dengan sasis Monocage II serat karbon, akselerasi 0-100 km/jam dalam 2,7 detik, dan pengendalian hidrolik presisi.'
      },
      {
        id: 'aston-martin-db12',
        name: 'Aston Martin DB12',
        brand: 'Aston Martin',
        category: 'Grand Tourer',
        year: 2025,
        status: 'Ready Stock',
        price: 15000000000,
        engine: '4.0L V8 Twin-Turbo',
        powerHp: 671,
        powerLabel: '671 HP',
        torque: '800 Nm',
        accelSec: 3.6,
        accelLabel: '3.6 dtk',
        topSpeed: '325 km/jam',
        transmission: '8-Speed Automatic',
        color: 'British Racing Green',
        image: 'images/aston-martin-db12.jpg',
        desc: 'Super Tourer pertama di dunia yang memadukan kemewahan kabin kulit buatan tangan Inggris dengan tenaga buas V8 Twin-Turbo.'
      },
      {
        id: 'amg-gt-63-pro',
        name: 'Mercedes-AMG GT 63 PRO',
        brand: 'Mercedes-AMG',
        category: 'Grand Tourer',
        year: 2026,
        status: 'New Arrival',
        price: 9300000000,
        engine: '4.0L V8 Biturbo 4MATIC+',
        powerHp: 612,
        powerLabel: '612 HP',
        torque: '850 Nm',
        accelSec: 3.2,
        accelLabel: '3.2 dtk',
        topSpeed: '317 km/jam',
        transmission: 'AMG SPEEDSHIFT MCT 9G',
        color: 'Selenite Grey Magno',
        image: 'images/mercedes-amg-gt-63-pro.jpg',
        desc: 'Coupe performa tinggi rakitan tangan Affalterbach dengan penggerak semua roda 4MATIC+, torsi masif 850 Nm, dan aura agresif nan elegan.'
      }
    ];

    const state = {
      selectedCategory: 'Semua',
      searchQuery: '',
      sortBy: 'featured',
      wishlist: [],
      compareIds: [],
      carouselIdx: 0,
      autoplay: true,
      autoplayTimer: null
    };

    // Load wishlist safely
    try {
      const saved = localStorage.getItem('danarsport_wishlist');
      if (saved) state.wishlist = JSON.parse(saved);
    } catch (e) {}

    function saveWishlist() {
      try {
        localStorage.setItem('danarsport_wishlist', JSON.stringify(state.wishlist));
      } catch (e) {}
    }

    function formatIDR(num) {
      return 'Rp ' + Math.round(num).toLocaleString('id-ID');
    }

    function showToast(msg) {
      const toast = document.getElementById('toast');
      document.getElementById('toastMsg').textContent = msg;
      toast.classList.remove('translate-x-full', 'opacity-0');
      clearTimeout(window._toastTimer);
      window._toastTimer = setTimeout(() => {
        toast.classList.add('translate-x-full', 'opacity-0');
      }, 3000);
    }

    // Carousel Rendering & Autoplay
    function renderCarousel() {
      const car = CARS[state.carouselIdx];
      const container = document.getElementById('carouselContainer');
      container.innerHTML = `
        <div class="grid grid-cols-1 lg:grid-cols-12 items-center">
          <div class="lg:col-span-7 relative h-64 sm:h-80 lg:h-[420px] overflow-hidden bg-black">
            <img src="${car.image}" alt="${car.name}" class="w-full h-full object-cover transition-transform duration-700 hover:scale-105" />
            <div class="absolute top-4 left-4 px-3 py-1 rounded-full bg-obsidian/80 backdrop-blur-md border border-gold-500/40 text-gold-400 text-xs font-bold uppercase tracking-wider">
              ${car.status} • ${car.year}
            </div>
          </div>
          <div class="lg:col-span-5 p-6 sm:p-8 lg:p-10 space-y-5">
            <div>
              <span class="text-xs font-semibold uppercase tracking-widest text-gold-400">${car.category}</span>
              <h3 class="text-2xl sm:text-3xl font-bold text-white mt-1">${car.name}</h3>
              <p class="text-2xl font-extrabold text-gold-400 mt-2">${formatIDR(car.price)}</p>
            </div>
            <p class="text-sm text-zinc-300 leading-relaxed">${car.desc}</p>
            <div class="grid grid-cols-3 gap-3 py-3 border-y border-white/10 text-center">
              <div>
                <div class="text-xs text-zinc-400">Tenaga</div>
                <div class="text-sm font-bold text-white mt-0.5">${car.powerLabel}</div>
              </div>
              <div>
                <div class="text-xs text-zinc-400">0-100 km/j</div>
                <div class="text-sm font-bold text-white mt-0.5">${car.accelLabel}</div>
              </div>
              <div>
                <div class="text-xs text-zinc-400">Top Speed</div>
                <div class="text-sm font-bold text-white mt-0.5">${car.topSpeed}</div>
              </div>
            </div>
            <div class="flex flex-wrap gap-3">
              <button type="button" onclick="openDetailModal('${car.id}')" class="flex-1 py-2.5 px-4 rounded-xl bg-gold-500 hover:bg-gold-400 text-obsidian font-bold text-sm transition-colors">
                Lihat Detail
              </button>
              <a href="https://wa.me/6285167029747?text=${encodeURIComponent('Halo DANARSPORT, saya tertarik dengan ' + car.name + ' (' + formatIDR(car.price) + ').')}" target="_blank" rel="noopener noreferrer" class="py-2.5 px-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/15 text-white font-semibold text-sm transition-colors">
                Tanya Unit
              </a>
            </div>
          </div>
        </div>
      `;

      const dotsEl = document.getElementById('carouselDots');
      dotsEl.innerHTML = CARS.map((_, idx) => `
        <button type="button" onclick="goToSlide(${idx})" aria-label="Slide ${idx + 1}" class="h-2 rounded-full transition-all ${idx === state.carouselIdx ? 'w-8 bg-gold-400' : 'w-2 bg-zinc-700 hover:bg-zinc-500'}"></button>
      `).join('');
    }

    function goToSlide(idx) {
      state.carouselIdx = (idx + CARS.length) % CARS.length;
      renderCarousel();
    }

    function startAutoplay() {
      clearInterval(state.autoplayTimer);
      if (state.autoplay) {
        state.autoplayTimer = setInterval(() => {
          goToSlide(state.carouselIdx + 1);
        }, 4500);
      }
    }

    // Filter & Render Cars
    function getFilteredCars() {
      let list = CARS.filter(car => {
        const matchCat = state.selectedCategory === 'Semua' || car.category === state.selectedCategory;
        const q = state.searchQuery.trim().toLowerCase();
        const matchQuery = !q || car.name.toLowerCase().includes(q) || car.brand.toLowerCase().includes(q) || car.engine.toLowerCase().includes(q);
        return matchCat && matchQuery;
      });

      if (state.sortBy === 'price-asc') list.sort((a, b) => a.price - b.price);
      else if (state.sortBy === 'price-desc') list.sort((a, b) => b.price - a.price);
      else if (state.sortBy === 'power-desc') list.sort((a, b) => b.powerHp - a.powerHp);
      else if (state.sortBy === 'accel-asc') list.sort((a, b) => a.accelSec - b.accelSec);

      return list;
    }

    function renderCars() {
      const grid = document.getElementById('carGrid');
      const empty = document.getElementById('emptyState');
      const filtered = getFilteredCars();

      if (filtered.length === 0) {
        grid.innerHTML = '';
        empty.classList.remove('hidden');
        return;
      }

      empty.classList.add('hidden');
      grid.innerHTML = filtered.map(car => {
        const isFav = state.wishlist.includes(car.id);
        const isCmp = state.compareIds.includes(car.id);
        return `
          <article class="car-card bg-carbon rounded-2xl border border-white/10 overflow-hidden flex flex-col">
            <div class="relative h-56 overflow-hidden bg-black cursor-pointer" onclick="openDetailModal('${car.id}')">
              <img src="${car.image}" alt="${car.name}" class="car-img w-full h-full object-cover" />
              <div class="absolute inset-0 bg-gradient-to-t from-carbon via-transparent to-transparent opacity-80"></div>
              <div class="absolute top-3 left-3 flex items-center gap-2">
                <span class="px-2.5 py-1 rounded-full bg-obsidian/80 backdrop-blur-md border border-gold-500/40 text-gold-400 text-[11px] font-bold uppercase">${car.status}</span>
                <span class="px-2.5 py-1 rounded-full bg-obsidian/80 backdrop-blur-md border border-white/10 text-zinc-200 text-[11px] font-medium">${car.year}</span>
              </div>
              <button type="button" onclick="event.stopPropagation(); toggleWishlist('${car.id}')" class="absolute top-3 right-3 w-9 h-9 rounded-full bg-obsidian/80 backdrop-blur-md border border-white/15 flex items-center justify-center transition-colors ${isFav ? 'text-rose-500 border-rose-500/40' : 'text-zinc-300 hover:text-white'}" aria-label="Favorit">
                <i data-lucide="heart" class="w-4 h-4 ${isFav ? 'fill-current' : ''}"></i>
              </button>
            </div>

            <div class="p-5 flex-1 flex flex-col justify-between">
              <div>
                <div class="flex items-center justify-between gap-2 mb-1">
                  <span class="text-xs font-semibold uppercase tracking-wider text-gold-400">${car.category}</span>
                  <span class="text-xs text-zinc-400">${car.color}</span>
                </div>
                <h3 class="text-xl font-bold text-white leading-snug cursor-pointer hover:text-gold-400 transition-colors" onclick="openDetailModal('${car.id}')">${car.name}</h3>
                <div class="text-xl font-extrabold text-gold-400 mt-2">${formatIDR(car.price)}</div>

                <div class="grid grid-cols-3 gap-2 mt-4 pt-4 border-t border-white/10 text-xs">
                  <div class="bg-obsidian/60 rounded-lg p-2 text-center">
                    <div class="text-zinc-500 text-[10px] uppercase">Tenaga</div>
                    <div class="font-bold text-white mt-0.5">${car.powerLabel}</div>
                  </div>
                  <div class="bg-obsidian/60 rounded-lg p-2 text-center">
                    <div class="text-zinc-500 text-[10px] uppercase">0-100</div>
                    <div class="font-bold text-white mt-0.5">${car.accelLabel}</div>
                  </div>
                  <div class="bg-obsidian/60 rounded-lg p-2 text-center">
                    <div class="text-zinc-500 text-[10px] uppercase">Top Speed</div>
                    <div class="font-bold text-white mt-0.5">${car.topSpeed}</div>
                  </div>
                </div>
              </div>

              <div class="mt-5 pt-4 border-t border-white/10 flex items-center gap-2">
                <button type="button" onclick="openDetailModal('${car.id}')" class="flex-1 py-2.5 px-3 rounded-xl bg-white/5 hover:bg-gold-500 hover:text-obsidian border border-white/10 hover:border-gold-500 text-white font-semibold text-xs sm:text-sm transition-all">
                  Detail Unit
                </button>
                <button type="button" onclick="toggleCompare('${car.id}')" class="py-2.5 px-3 rounded-xl border text-xs font-semibold transition-all ${isCmp ? 'bg-gold-500/20 border-gold-500 text-gold-400' : 'bg-white/5 border-white/10 text-zinc-300 hover:text-white'}" title="Bandingkan">
                  ${isCmp ? '✓ Banding' : '+ Banding'}
                </button>
                <a href="https://wa.me/6285167029747?text=${encodeURIComponent('Halo DANARSPORT, saya ingin menanyakan ketersediaan ' + car.name + ' (' + formatIDR(car.price) + ').')}" target="_blank" rel="noopener noreferrer" class="p-2.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500 text-emerald-400 hover:text-obsidian border border-emerald-500/30 transition-all" title="Chat WhatsApp 085167029747">
                  <i data-lucide="message-circle" class="w-4 h-4"></i>
                </a>
              </div>
            </div>
          </article>
        `;
      }).join('');

      lucide.createIcons();
    }

    // Wishlist Logic
    function updateWishlistBadge() {
      const badge = document.getElementById('wishlistCount');
      if (state.wishlist.length > 0) {
        badge.textContent = state.wishlist.length;
        badge.classList.remove('hidden');
      } else {
        badge.classList.add('hidden');
      }
    }

    function toggleWishlist(id) {
      const idx = state.wishlist.indexOf(id);
      const car = CARS.find(c => c.id === id);
      if (idx === -1) {
        state.wishlist.push(id);
        showToast(car.name + ' ditambahkan ke Favorit');
      } else {
        state.wishlist.splice(idx, 1);
        showToast(car.name + ' dihapus dari Favorit');
      }
      saveWishlist();
      updateWishlistBadge();
      renderCars();
      renderWishlistModal();
    }

    function renderWishlistModal() {
      const body = document.getElementById('wishlistModalBody');
      if (state.wishlist.length === 0) {
        body.innerHTML = '<p class="text-sm text-zinc-400 text-center py-8">Belum ada mobil favorit. Klik ikon hati pada unit yang Anda sukai.</p>';
        return;
      }
      body.innerHTML = state.wishlist.map(id => {
        const car = CARS.find(c => c.id === id);
        if (!car) return '';
        return `
          <div class="flex items-center gap-3 p-3 rounded-xl bg-obsidian border border-white/10">
            <img src="${car.image}" alt="${car.name}" class="w-20 h-14 object-cover rounded-lg shrink-0" />
            <div class="flex-1 min-w-0">
              <div class="text-sm font-bold text-white truncate">${car.name}</div>
              <div class="text-xs font-semibold text-gold-400">${formatIDR(car.price)}</div>
            </div>
            <button type="button" onclick="closeAllModals(); openDetailModal('${car.id}')" class="px-2.5 py-1.5 rounded-lg bg-white/10 hover:bg-gold-500 hover:text-obsidian text-xs font-semibold transition-colors">Lihat</button>
            <button type="button" onclick="toggleWishlist('${car.id}')" class="p-1.5 text-zinc-400 hover:text-rose-400" aria-label="Hapus">
              <i data-lucide="trash-2" class="w-4 h-4"></i>
            </button>
          </div>
        `;
      }).join('');
      lucide.createIcons();
    }

    // Compare Logic
    function toggleCompare(id) {
      const idx = state.compareIds.indexOf(id);
      if (idx !== -1) {
        state.compareIds.splice(idx, 1);
      } else {
        if (state.compareIds.length >= 3) {
          showToast('Maksimal 3 unit untuk dibandingkan sekaligus');
          return;
        }
        state.compareIds.push(id);
      }
      updateCompareBar();
      renderCars();
    }

    function updateCompareBar() {
      const bar = document.getElementById('compareBar');
      const countEl = document.getElementById('compareCountText');
      if (state.compareIds.length > 0) {
        countEl.textContent = state.compareIds.length;
        bar.classList.remove('hidden');
      } else {
        bar.classList.add('hidden');
      }
    }

    function openCompareModal() {
      const items = state.compareIds.map(id => CARS.find(c => c.id === id)).filter(Boolean);
      const body = document.getElementById('compareModalBody');
      if (items.length < 2) {
        showToast('Pilih minimal 2 unit untuk membandingkan');
        return;
      }
      body.innerHTML = `
        <table class="w-full text-left text-sm border-collapse">
          <thead>
            <tr class="border-b border-white/10">
              <th class="py-3 pr-4 text-xs uppercase text-zinc-400">Spesifikasi</th>
              ${items.map(c => `
                <th class="py-3 px-3 min-w-[180px]">
                  <img src="${c.image}" alt="${c.name}" class="w-full h-28 object-cover rounded-lg mb-2" />
                  <div class="font-bold text-white">${c.name}</div>
                </th>
              `).join('')}
            </tr>
          </thead>
          <tbody class="divide-y divide-white/10 text-zinc-200">
            <tr><td class="py-3 pr-4 text-zinc-400">Harga OTR</td>${items.map(c => `<td class="py-3 px-3 font-bold text-gold-400">${formatIDR(c.price)}</td>`).join('')}</tr>
            <tr><td class="py-3 pr-4 text-zinc-400">Mesin</td>${items.map(c => `<td class="py-3 px-3">${c.engine}</td>`).join('')}</tr>
            <tr><td class="py-3 pr-4 text-zinc-400">Tenaga</td>${items.map(c => `<td class="py-3 px-3 font-semibold">${c.powerLabel}</td>`).join('')}</tr>
            <tr><td class="py-3 pr-4 text-zinc-400">Torsi</td>${items.map(c => `<td class="py-3 px-3">${c.torque}</td>`).join('')}</tr>
            <tr><td class="py-3 pr-4 text-zinc-400">0-100 km/jam</td>${items.map(c => `<td class="py-3 px-3 font-semibold">${c.accelLabel}</td>`).join('')}</tr>
            <tr><td class="py-3 pr-4 text-zinc-400">Top Speed</td>${items.map(c => `<td class="py-3 px-3">${c.topSpeed}</td>`).join('')}</tr>
            <tr><td class="py-3 pr-4 text-zinc-400">Transmisi</td>${items.map(c => `<td class="py-3 px-3">${c.transmission}</td>`).join('')}</tr>
          </tbody>
        </table>
      `;
      document.getElementById('compareModal').classList.add('open');
    }

    // Detail Modal
    function openDetailModal(id) {
      const car = CARS.find(c => c.id === id);
      if (!car) return;
      const content = document.getElementById('detailModalContent');
      content.innerHTML = `
        <div class="relative h-64 sm:h-80 bg-black">
          <img src="${car.image}" alt="${car.name}" class="w-full h-full object-cover" />
          <button type="button" onclick="closeAllModals()" class="absolute top-4 right-4 p-2 rounded-full bg-obsidian/80 text-white hover:bg-obsidian border border-white/15" aria-label="Tutup">
            <i data-lucide="x" class="w-5 h-5"></i>
          </button>
          <div class="absolute bottom-4 left-6 px-3 py-1 rounded-full bg-obsidian/80 backdrop-blur-md border border-gold-500/40 text-gold-400 text-xs font-bold uppercase">
            ${car.category} • ${car.year}
          </div>
        </div>
        <div class="p-6 sm:p-8 space-y-6">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 class="text-2xl sm:text-3xl font-bold text-white">${car.name}</h3>
              <p class="text-sm text-zinc-400 mt-0.5">Warna Eksterior: ${car.color} • Status: ${car.status}</p>
            </div>
            <div class="text-2xl font-extrabold text-gold-400">${formatIDR(car.price)}</div>
          </div>

          <p class="text-sm text-zinc-300 leading-relaxed">${car.desc}</p>

          <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 text-sm">
            <div class="p-3 rounded-xl bg-obsidian border border-white/10"><div class="text-xs text-zinc-400">Mesin</div><div class="font-semibold text-white mt-0.5">${car.engine}</div></div>
            <div class="p-3 rounded-xl bg-obsidian border border-white/10"><div class="text-xs text-zinc-400">Tenaga Maks</div><div class="font-semibold text-white mt-0.5">${car.powerLabel}</div></div>
            <div class="p-3 rounded-xl bg-obsidian border border-white/10"><div class="text-xs text-zinc-400">Torsi Maks</div><div class="font-semibold text-white mt-0.5">${car.torque}</div></div>
            <div class="p-3 rounded-xl bg-obsidian border border-white/10"><div class="text-xs text-zinc-400">Akselerasi 0-100</div><div class="font-semibold text-white mt-0.5">${car.accelLabel}</div></div>
            <div class="p-3 rounded-xl bg-obsidian border border-white/10"><div class="text-xs text-zinc-400">Kecepatan Maks</div><div class="font-semibold text-white mt-0.5">${car.topSpeed}</div></div>
            <div class="p-3 rounded-xl bg-obsidian border border-white/10"><div class="text-xs text-zinc-400">Transmisi</div><div class="font-semibold text-white mt-0.5">${car.transmission}</div></div>
          </div>

          <div class="flex flex-col sm:flex-row gap-3 pt-2">
            <button type="button" onclick="openBookingForCar('${car.id}')" class="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-gold-400 to-gold-600 text-obsidian font-bold text-sm hover:opacity-95 transition-opacity">
              Jadwalkan Test Drive
            </button>
            <button type="button" onclick="jumpToSimulator('${car.id}')" class="py-3 px-4 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold text-sm transition-colors">
              Simulasi Kredit
            </button>
            <a href="https://wa.me/6285167029747?text=${encodeURIComponent('Halo DANARSPORT, saya ingin memesan / menanyakan unit ' + car.name + ' seharga ' + formatIDR(car.price) + '.')}" target="_blank" rel="noopener noreferrer" class="py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-obsidian font-bold text-sm text-center transition-colors">
              WhatsApp: 085167029747
            </a>
          </div>
        </div>
      `;
      lucide.createIcons();
      document.getElementById('detailModal').classList.add('open');
    }

    function jumpToSimulator(carId) {
      closeAllModals();
      document.getElementById('simCarSelect').value = carId;
      updateSimulator();
      document.getElementById('simulasi').scrollIntoView({ behavior: 'smooth' });
    }

    function openBookingForCar(carId) {
      closeAllModals();
      if (carId) document.getElementById('bookCar').value = carId;
      document.getElementById('bookingForm').classList.remove('hidden');
      document.getElementById('bookingSuccessBox').classList.add('hidden');
      document.getElementById('bookingModal').classList.add('open');
    }

    function closeAllModals() {
      document.querySelectorAll('.modal-backdrop').forEach(el => el.classList.remove('open'));
    }

    // Credit Simulator
    function initSimulator() {
      const select = document.getElementById('simCarSelect');
      const bookSelect = document.getElementById('bookCar');
      const opts = CARS.map(c => `<option value="${c.id}">${c.name} (${formatIDR(c.price)})</option>`).join('');
      select.innerHTML = opts;
      bookSelect.innerHTML = opts;

      const update = () => {
        const car = CARS.find(c => c.id === select.value) || CARS[0];
        const dpPct = Number(document.getElementById('simDpRange').value);
        const tenor = Number(document.getElementById('simTenorRange').value);
        document.getElementById('simDpLabel').textContent = dpPct + '%';
        document.getElementById('simTenorLabel').textContent = tenor + ' Bulan';

        const dpAmount = car.price * (dpPct / 100);
        const principal = car.price - dpAmount;
        const annualRate = 0.055;
        const years = tenor / 12;
        const totalPayable = principal * (1 + annualRate * years);
        const monthly = totalPayable / tenor;

        document.getElementById('simMonthlyResult').textContent = formatIDR(monthly) + ' / bln';
        document.getElementById('simBreakdown').textContent = `DP: ${formatIDR(dpAmount)} • Pokok Hutang: ${formatIDR(principal)} • Bunga 5.5% p.a`;
      };

      window.updateSimulator = update;
      select.addEventListener('change', update);
      document.getElementById('simDpRange').addEventListener('input', update);
      document.getElementById('simTenorRange').addEventListener('input', update);
      update();
    }

    // Initialization
    document.addEventListener('DOMContentLoaded', () => {
      // Populate default date for test drive
      const today = new Date();
      today.setDate(today.getDate() + 1);
      document.getElementById('bookDate').value = today.toISOString().split('T')[0];

      renderCarousel();
      startAutoplay();
      renderCars();
      updateWishlistBadge();
      initSimulator();
      lucide.createIcons();

      // Carousel controls
      document.getElementById('prevSlideBtn').addEventListener('click', () => goToSlide(state.carouselIdx - 1));
      document.getElementById('nextSlideBtn').addEventListener('click', () => goToSlide(state.carouselIdx + 1));
      document.getElementById('toggleAutoplayBtn').addEventListener('click', () => {
        state.autoplay = !state.autoplay;
        document.getElementById('autoplayLabel').textContent = state.autoplay ? 'Auto-Slide Aktif' : 'Auto-Slide Dijeda';
        document.getElementById('autoplayIcon').setAttribute('data-lucide', state.autoplay ? 'pause' : 'play');
        lucide.createIcons();
        startAutoplay();
      });

      // Category filter pills
      document.querySelectorAll('.cat-pill').forEach(btn => {
        btn.addEventListener('click', () => {
          state.selectedCategory = btn.dataset.cat;
          document.querySelectorAll('.cat-pill').forEach(b => {
            b.className = 'cat-pill px-4 py-2 rounded-full text-xs sm:text-sm font-medium bg-carbon text-zinc-300 border border-white/10 hover:border-gold-500/50 transition-all';
          });
          btn.className = 'cat-pill px-4 py-2 rounded-full text-xs sm:text-sm font-semibold bg-gold-500 text-obsidian transition-all';
          renderCars();
        });
      });

      // Search & Sort
      document.getElementById('searchInput').addEventListener('input', (e) => {
        state.searchQuery = e.target.value;
        renderCars();
      });
      document.getElementById('sortSelect').addEventListener('change', (e) => {
        state.sortBy = e.target.value;
        renderCars();
      });
      document.getElementById('resetFilterBtn').addEventListener('click', () => {
        state.selectedCategory = 'Semua';
        state.searchQuery = '';
        state.sortBy = 'featured';
        document.getElementById('searchInput').value = '';
        document.getElementById('sortSelect').value = 'featured';
        document.querySelectorAll('.cat-pill')[0].click();
      });

      // Mobile menu
      const mobileMenu = document.getElementById('mobileMenu');
      document.getElementById('mobileMenuBtn').addEventListener('click', () => mobileMenu.classList.toggle('hidden'));
      document.querySelectorAll('.mobile-nav-link').forEach(a => a.addEventListener('click', () => mobileMenu.classList.add('hidden')));

      // Modals
      document.getElementById('wishlistBtn').addEventListener('click', () => {
        renderWishlistModal();
        document.getElementById('wishlistModal').classList.add('open');
      });
      document.getElementById('closeWishlistModalBtn').addEventListener('click', closeAllModals);
      document.getElementById('openCompareModalBtn').addEventListener('click', openCompareModal);
      document.getElementById('closeCompareModalBtn').addEventListener('click', closeAllModals);
      document.getElementById('clearCompareBtn').addEventListener('click', () => {
        state.compareIds = [];
        updateCompareBar();
        renderCars();
      });

      document.getElementById('openBookingNavBtn').addEventListener('click', () => openBookingForCar());
      document.getElementById('footerBookBtn').addEventListener('click', () => openBookingForCar());
      document.getElementById('simInquiryBtn').addEventListener('click', () => {
        const carId = document.getElementById('simCarSelect').value;
        openBookingForCar(carId);
      });
      document.getElementById('closeBookingModalBtn').addEventListener('click', closeAllModals);

      document.querySelectorAll('.modal-backdrop').forEach(backdrop => {
        backdrop.addEventListener('click', (e) => {
          if (e.target === backdrop) closeAllModals();
        });
      });

      // Booking Form Submit
      document.getElementById('bookingForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('bookName').value.trim();
        const phone = document.getElementById('bookPhone').value.trim();
        const carId = document.getElementById('bookCar').value;
        const date = document.getElementById('bookDate').value;
        const time = document.getElementById('bookTime').value;
        const car = CARS.find(c => c.id === carId) || CARS[0];

        document.getElementById('bookingForm').classList.add('hidden');
        document.getElementById('bookingSuccessBox').classList.remove('hidden');
        document.getElementById('bookingSuccessSummary').textContent =
          `Terima kasih ${name} (${phone}). Jadwal Test Drive ${car.name} pada ${date} pukul ${time} telah dicatat.`;

        const waMsg = `Halo DANARSPORT, saya ${name} (${phone}) ingin konfirmasi jadwal Test Drive VIP untuk unit ${car.name} pada tanggal ${date} pukul ${time}.`;
        document.getElementById('bookingWaLink').href = `https://wa.me/6285167029747?text=${encodeURIComponent(waMsg)}`;
        showToast('Jadwal Test Drive berhasil dicatat!');
      });

      // Scroll Reveal Observer
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) entry.target.classList.add('visible');
        });
      }, { threshold: 0.12 });
      document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
    });
